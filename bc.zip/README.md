# Blog service
### Requirements
- Audio
- Video
- Dropdown
- Geo-location
- Canvas
- Fonts
